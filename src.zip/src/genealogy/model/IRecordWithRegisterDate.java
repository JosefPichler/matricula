package genealogy.model;

public interface IRecordWithRegisterDate {

	RegisterDate getRegisterDate();
	
}
