package matricula.ui;

public interface ITreeModelFilter {

	void setFilter(String filterString);

}
