package matricula.report;

import matricula.model.PersonTag;

public abstract class PersonTagKeyBuilder {

	public abstract String makeKey(PersonTag p);

}
