package matricula.report;

import matricula.model.PersonTag;

public abstract class PersonTagFilter {

	public abstract boolean accept(PersonTag tag);
}
